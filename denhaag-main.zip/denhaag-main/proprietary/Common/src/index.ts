export default require('./index.css');
