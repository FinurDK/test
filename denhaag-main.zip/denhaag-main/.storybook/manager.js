import { addons } from '@storybook/addons';
import denhaagTheme from './denhaagTheme';

addons.setConfig({
  theme: denhaagTheme,
});
