License
Copyright (c) 2021 Gemeente Den Haag. All rights reserved.

The open source license does NOT apply to files in this directory.

These are properietary assets to Gemeente Den Haag.
