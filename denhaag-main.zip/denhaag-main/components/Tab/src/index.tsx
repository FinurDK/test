import Tab from './Tab';

export default Tab;
export * from './Tab';
export * from './TabContext';
export * from './TabList';
export * from './TabPanel';
export * from './TabScrollButton';
export * from './Tabs';
