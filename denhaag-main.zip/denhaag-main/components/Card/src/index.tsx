import Card from './Card/Card';

export default Card;
export * from './Card/Card';
