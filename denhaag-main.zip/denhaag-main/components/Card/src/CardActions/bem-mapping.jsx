export const cardActionClasses = {
  root: 'denhaag-card__actions',
};
