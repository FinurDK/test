export const cardClasses = {
  root: 'denhaag-card',
};

export const cardArrowClasses = {
  root: 'denhaag-card__arrow',
};

export const cardTitleClasses = {
  root: 'denhaag-card__title',
};

export const cardSubtitleClasses = {
  root: 'denhaag-card__subtitle',
};

export const cardPaperClasses = {
  root: 'denhaag-card__paper',
};

export const cardCaseClasses = {
  root: 'denhaag-card--case',
};

export const cardArchivedClasses = {
  root: 'denhaag-card--archived',
};
