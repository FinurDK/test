export const CardContentClasses = {
  root: 'denhaag-card__content',
};
