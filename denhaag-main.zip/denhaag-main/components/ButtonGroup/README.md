# Button Group

Button groups are used to group buttons.

## When to use

Mainly used to wrap buttons in the Gutenberg Editor of WordPress.

## Anatomy

The button group consists of:

1. Container
