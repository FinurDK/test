import AnchorCollapses from './anchorCollapses';

window.addEventListener('DOMContentLoaded', async () => {
  setTimeout(() => {
    new AnchorCollapses('denhaag-anchor-collapse');
  }, 500);
});
