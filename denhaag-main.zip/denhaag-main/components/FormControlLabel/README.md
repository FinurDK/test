# FormControlLabel

![npm (scoped)](https://img.shields.io/npm/v/@gemeente-denhaag/formcontrollabel?logo=npm&style=flat-square)
![GitHub Workflow Status (branch)](https://img.shields.io/github/workflow/status/nl-design-system/denhaag/Build%20and%20deploy%20Storybook%20to%20Azure%20Web%20App/main?logo=github&style=flat-square)

This component is used to add a label to a CheckBox or Radio.

For an example of how this component is used, see the [Checkbox](../?path=/docs/components-input-checkbox--default) component.
