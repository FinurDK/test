import TableScroll from './TableScroll';

window.addEventListener('DOMContentLoaded', () => {
  TableScroll();
});

window.addEventListener('resize', () => {
  TableScroll();
});
