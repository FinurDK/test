export * from './Heading1';
export * from './Heading2';
export * from './Heading3';
export * from './Heading4';
export * from './Heading5';

export * from './Paragraph';
export * from './LeadParagraph';
