import PageButtonsScripts from './pageButtonsScripts';

window.addEventListener('DOMContentLoaded', async () => {
  window.onload = () => new PageButtonsScripts('denhaag-share-button');
});
