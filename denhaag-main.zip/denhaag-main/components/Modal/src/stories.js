import ModalScripts from './modal';

window.addEventListener('DOMContentLoaded', () => {
  window.onload = () => new ModalScripts('denhaag-modal');
});
