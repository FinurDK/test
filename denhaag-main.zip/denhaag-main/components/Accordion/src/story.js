import AccordionToggle from './AccordionToggle';

window.addEventListener('DOMContentLoaded', () => {
  AccordionToggle();
});
