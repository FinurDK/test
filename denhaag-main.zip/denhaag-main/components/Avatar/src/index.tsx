import Avatar from './Avatar';

export default Avatar;
export * from './Avatar';
