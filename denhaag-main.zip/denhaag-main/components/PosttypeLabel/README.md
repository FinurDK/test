# Posttype Label

Label of the page type.

## When to use

None.

## Anatomy

On top of Title.

## Design properties

**Typography**

- Text: Sans/sm/700

**Colors**

- Text: text color Blue/3

**Structure**

None.

## Accessibility

None.

## Content guidelines

None.

## Best practices

### Do's

None.

### Don'ts

None.

## References

- Current posttype label: https://www.denhaag.nl/nl/in-de-stad/nieuws/nieuwe-erfpachtfactuur-staat-in-mijndenhaag.htm
