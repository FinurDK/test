import React from 'react';

export const SubStepHeading: React.FC = ({ children }) => (
  <p className={'denhaag-process-steps__sub-step-heading'}>{children}</p>
);

export default SubStepHeading;
